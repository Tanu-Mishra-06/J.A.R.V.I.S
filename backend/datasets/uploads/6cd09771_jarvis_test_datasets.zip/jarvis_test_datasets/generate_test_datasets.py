"""Generate test datasets for J.A.R.V.I.S. (payment platform, services prefixed pay-).

Creates, for three scenarios, a JSONL log file and a JSONL trace (span) file:
  1. payments_db_exhaustion   root cause: pay-ledger-db   (login + payment + gateway symptoms)
  2. payments_bad_deploy      root cause: pay-checkout    (mid-tier fault; the deepest dependency is healthy)
  3. payments_noise           no incident expected        (isolated harmless warnings)

Topology (caller -> callee):
  pay-gateway  -> pay-auth, pay-checkout
  pay-auth     -> pay-redis, pay-ledger-db
  pay-checkout -> pay-fraud, pay-ledger-db

Run:  python generate_test_datasets.py   (fixed random seed, so output is reproducible)
"""
import json
import random
import zipfile
from datetime import datetime, timedelta, timezone
from pathlib import Path

BASE = datetime(2026, 11, 10, 9, 0, 0, tzinfo=timezone.utc)
T0 = 600          # incident starts 10 minutes after BASE (healthy baseline before)
TOTAL = 900       # 15 minutes of data

HOSTS = {
    "pay-gateway": "gw-pay-01", "pay-auth": "auth-pay-01", "pay-checkout": "checkout-pay-01",
    "pay-ledger-db": "ledger-db-01", "pay-redis": "redis-pay-01", "pay-fraud": "fraud-pay-01",
}
BASE_MS = {"pay-gateway": 15, "pay-auth": 20, "pay-checkout": 35,
           "pay-ledger-db": 8, "pay-redis": 3, "pay-fraud": 40}


def iso(sec):
    return (BASE + timedelta(seconds=sec)).strftime("%Y-%m-%dT%H:%M:%S.%f")[:-3] + "Z"


# ----------------------------------------------------------------- scenarios
class Scenario:
    name = ""
    expected = None
    notes = ""

    def fault(self, service, t, kind):
        """Return (error_prob, timeout_ms, slow_extra_ms, message)."""
        return 0.0, 0, 0, ""

    def infra_logs(self):
        return []

    def trace_interval(self, t):
        return 5.0


class DbExhaustion(Scenario):
    name = "payments_db_exhaustion"
    expected = "pay-ledger-db"
    notes = ("Ledger DB connection pool saturates, so login failures (pay-auth), failed payments "
             "(pay-checkout) and gateway 504s follow. One incident expected.")

    def fault(self, service, t, kind):
        if service != "pay-ledger-db":
            return 0.0, 0, 0, ""
        if T0 <= t < T0 + 10:
            return 0.0, 0, 150, ""
        if T0 + 10 <= t < T0 + 160:
            p = min(1.0, (t - (T0 + 10)) / 30.0)
            return p * 0.95, 6000, int(700 * p), "connection pool exhausted (1000/1000)"
        return 0.0, 0, 0, ""

    def infra_logs(self):
        out = [(T0, "pay-ledger-db", "WARN", "connection pool usage at 85% (850/1000)"),
               (T0 + 5, "pay-ledger-db", "WARN", "connection pool usage at 93% (930/1000)")]
        queued = 120
        t = T0 + 10
        while t < T0 + 160:
            queued += random.randint(15, 60)
            out.append((t, "pay-ledger-db", "ERROR",
                        f"connection pool exhausted (1000/1000), {queued} queued requests"))
            t += 4
        out.append((T0 + 160, "pay-ledger-db", "INFO", "connection pool recovered (310/1000)"))
        return out

    def trace_interval(self, t):
        return 2.0 if T0 <= t < T0 + 180 else 5.0


class BadDeploy(Scenario):
    name = "payments_bad_deploy"
    expected = "pay-checkout"
    notes = ("A faulty release of pay-checkout throws exceptions right after deployment. The deepest "
             "dependency (pay-ledger-db) stays healthy and login keeps working, so a naive "
             "'deepest service is the root cause' rule would be wrong. One incident expected.")

    def fault(self, service, t, kind):
        if service == "pay-checkout" and kind == "pay" and T0 + 15 <= t < T0 + 170:
            return 0.9, 60, 0, "NullPointerException in PaymentValidator.validate (v2.14.0)"
        return 0.0, 0, 0, ""

    def infra_logs(self):
        out = [(T0, "pay-checkout", "INFO", "deployment v2.14.0 started"),
               (T0 + 12, "pay-checkout", "INFO", "deployment v2.14.0 rolled out to 3/3 pods")]
        t = T0 + 20
        rate = 40
        while t < T0 + 170:
            rate = min(95, rate + random.randint(2, 8))
            out.append((t, "pay-checkout", "ERROR", f"unhandled exception rate {rate}% since v2.14.0"))
            t += 8
        out.append((T0 + 175, "pay-checkout", "INFO", "deployment v2.14.0 rolled back to v2.13.4"))
        return out

    def trace_interval(self, t):
        return 2.0 if T0 <= t < T0 + 190 else 5.0


class Noise(Scenario):
    name = "payments_noise"
    expected = None
    notes = ("Healthy traffic with a few isolated, unrelated warnings far apart in time. "
             "No incident should be created.")

    def infra_logs(self):
        return [
            (210, "pay-redis", "WARN", "cache miss ratio 18% (threshold 15%)"),
            (420, "pay-fraud", "WARN", "rule set refresh took 900ms"),
            (560, "pay-gateway", "WARN", "slow client upload took 1200ms"),
            (700, "pay-redis", "WARN", "cache miss ratio 17% (threshold 15%)"),
            (800, "pay-auth", "WARN", "token cache eviction burst (42 entries)"),
        ]


# -------------------------------------------------------------------- traces
def make_trace(sc, t, kind, counter, rng):
    tid = f"tr-{rng.getrandbits(48):012x}"
    user = f"u_{rng.randint(1000, 1999)}"
    if kind == "login":
        gw_op, mid, mid_op = "POST /login", "pay-auth", "verify_credentials"
        leaves = [("pay-redis", "GET session"), ("pay-ledger-db", "SELECT user_credentials")]
    else:
        gw_op, mid, mid_op = "POST /pay", "pay-checkout", "create_transaction"
        leaves = [("pay-fraud", "score_transaction"), ("pay-ledger-db", "INSERT ledger_entry")]

    spans, logs = [], []
    sid = lambda: f"sp-{rng.getrandbits(32):08x}"
    gw_id, mid_id = sid(), sid()

    # leaves
    leaf_res = []
    for svc, op in leaves:
        p, timeout, extra, msg = sc.fault(svc, t, kind)
        if p and rng.random() < p:
            dur, status, m = timeout + rng.randint(-200, 200), "error", msg
        else:
            dur = BASE_MS[svc] * rng.uniform(0.8, 1.3) + (extra * rng.uniform(0.5, 1.0) if extra else 0)
            status, m = "ok", ""
        leaf_res.append((svc, op, sid(), dur, status, m))

    leaf_max = max(r[3] for r in leaf_res)
    leaf_err = [r for r in leaf_res if r[4] == "error"]

    # middle service
    p, timeout, extra, own_msg = sc.fault(mid, t, kind)
    own_fail = bool(p and rng.random() < p)
    if own_fail:
        mid_dur, mid_status, mid_msg = timeout + rng.randint(0, 30), "error", own_msg
    else:
        mid_dur = leaf_max + BASE_MS[mid] * rng.uniform(0.8, 1.3)
        if leaf_err:
            mid_status = "error"
            child = leaf_err[0][0]
            if mid == "pay-auth":
                mid_msg = (f"login failed: db timeout after {int(leaf_err[0][3])}ms"
                           if child == "pay-ledger-db" else "login failed: cache error")
            else:
                mid_msg = (f"txn failed: ledger timeout after {int(leaf_err[0][3])}ms"
                           if child == "pay-ledger-db" else "txn failed: fraud service error")
        else:
            mid_status, mid_msg = "ok", ""

    # gateway
    gw_dur = mid_dur + BASE_MS["pay-gateway"] * rng.uniform(0.8, 1.3)
    if mid_status == "error":
        gw_status = "error"
        if mid_dur < 1500:
            gw_msg = f"502 Bad Gateway from {mid}"
        else:
            gw_dur = min(gw_dur, 9000)
            gw_msg = f"504 Gateway Timeout from {mid} after {int(gw_dur)}ms"
    else:
        gw_status, gw_msg = "ok", ""

    def emit(svc, op, span_id, parent, start, dur, status, msg, kind_log):
        spans.append({
            "timestamp": iso(start), "trace_id": tid, "span_id": span_id,
            "parent_span_id": parent, "service": svc, "operation": op,
            "duration_ms": round(dur, 1), "status": status, "host": HOSTS[svc],
        })
        end = start + dur / 1000.0
        if status == "error":
            level, text = "ERROR", msg
        elif dur > 2000:
            level, text = "WARN", f"{op} slow: latency={int(dur)}ms"
        else:
            level = "INFO"
            text = {"pay-gateway": f"{op} 200 OK latency={int(dur)}ms",
                    "pay-auth": f"login success user={user}",
                    "pay-checkout": f"txn_{counter:06d} completed user={user}",
                    "pay-ledger-db": "query ok",
                    "pay-redis": "cache hit",
                    "pay-fraud": f"fraud score={rng.uniform(0.01, 0.2):.2f}"}[svc]
        entry = {"timestamp": iso(end), "service": svc, "level": level, "message": text,
                 "host": HOSTS[svc], "trace_id": tid, "latency_ms": round(dur, 1)}
        if svc in ("pay-gateway", "pay-auth", "pay-checkout"):
            entry["user_id"] = user
        logs.append(entry)

    emit("pay-gateway", gw_op, gw_id, None, t, gw_dur, gw_status, gw_msg, None)
    emit(mid, mid_op, mid_id, gw_id, t + 0.005, mid_dur, mid_status, mid_msg, None)
    for svc, op, span_id, dur, status, m in leaf_res:
        emit(svc, op, span_id, mid_id, t + 0.01, dur, status, m, None)
    return spans, logs


def build(sc, seed):
    rng = random.Random(seed)
    random.seed(seed)
    spans, logs = [], []
    t, n = 1.0, 0
    while t < TOTAL:
        n += 1
        s, l = make_trace(sc, t, "login" if n % 2 else "pay", n, rng)
        spans += s
        logs += l
        t += sc.trace_interval(t) * rng.uniform(0.8, 1.2)
    # infra heartbeat for healthy DB / cache (every ~30s) and scenario-specific logs
    for tt in range(5, TOTAL, 30):
        if not (isinstance(sc, DbExhaustion) and T0 <= tt < T0 + 165):
            logs.append({"timestamp": iso(tt), "service": "pay-ledger-db", "level": "INFO",
                         "message": f"connection pool usage {rng.randint(9, 14)}% ({rng.randint(90, 140)}/1000)",
                         "host": HOSTS["pay-ledger-db"]})
        logs.append({"timestamp": iso(tt + 7), "service": "pay-redis", "level": "INFO",
                     "message": f"cache hit ratio {rng.randint(93, 97)}%", "host": HOSTS["pay-redis"]})
    for tt, svc, level, msg in sc.infra_logs():
        logs.append({"timestamp": iso(tt), "service": svc, "level": level, "message": msg,
                     "host": HOSTS[svc]})
    logs.sort(key=lambda e: e["timestamp"])
    spans.sort(key=lambda e: e["timestamp"])
    return spans, logs


def main():
    out = Path(__file__).parent
    truth = []
    for i, sc in enumerate([DbExhaustion(), BadDeploy(), Noise()]):
        spans, logs = build(sc, seed=42 + i)
        (out / f"{sc.name}_logs.jsonl").write_text("\n".join(json.dumps(e) for e in logs) + "\n", encoding="utf-8")
        (out / f"{sc.name}_traces.jsonl").write_text("\n".join(json.dumps(e) for e in spans) + "\n", encoding="utf-8")
        truth.append({"scenario": sc.name, "logs_file": f"{sc.name}_logs.jsonl",
                      "traces_file": f"{sc.name}_traces.jsonl",
                      "expected_root_cause": sc.expected,
                      "expected_incidents": 0 if sc.expected is None else 1,
                      "notes": sc.notes})
        print(f"{sc.name}: {len(logs)} logs, {len(spans)} spans")
    (out / "ground_truth.json").write_text(json.dumps(truth, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
